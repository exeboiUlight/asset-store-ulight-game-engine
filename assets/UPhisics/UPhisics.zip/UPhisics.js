var phisics = {
    bodys: [],
    player: []
};

function NewPlayer(pos, size) {
    phisics.player = [pos, size];
}

function NewBody(pos, size) {
    phisics.bodys.push([pos, size]);
}

function RenderPhisics() {
    for (let i = 0; i < phisics.bodys.length; i++) {
        let playerPos = phisics.player[0];
        let playerSize = phisics.player[1];
        let bodyPos = phisics.bodys[i][0];
        let bodySize = phisics.bodys[i][1];

        if (playerPos.x + playerSize.x < bodyPos.x || playerPos.x > bodyPos.x + bodySize.x) {
            continue;
        }
        if (playerPos.y + playerSize.y < bodyPos.y || playerPos.y > bodyPos.y + bodySize.y) {
            continue;
        }
        if (playerPos.z + playerSize.z < bodyPos.z || playerPos.z > bodyPos.z + bodySize.z) {
             continue;
        }
        return true;
    }
    return false;
}
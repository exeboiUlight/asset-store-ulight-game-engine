var phisics = {
    bodys: [],
    player: []
};

function NewPlayer(pos, size) {
    phisics.player = [pos, size];
}

function NewBody(pos, size) {
    phisics.bodys.push([pos, size]);
}

function RenderPhisics() {
    for (let i = 0; i < phisics.bodys.length; i++) {
        let playerPos = phisics.player[0];
        let playerSize = phisics.player[1];
        let bodyPos = phisics.bodys[i][0];
        let bodySize = phisics.bodys[i][1];

        if (playerPos[0] + playerSize[0] < bodyPos[0] || playerPos[0] > bodyPos[0] + bodySize[0]) {
            continue;
        }
        if (playerPos[1] + playerSize[1] < bodyPos[1] || playerPos[1] > bodyPos[1] + bodySize[1]) {
            continue;
        }
        if (playerPos[2] + playerSize[2] < bodyPos[2] || playerPos[2] > bodyPos[2] + bodySize[2]) {
             continue;
        }
        return true;
    }
    return false;
}
